# python_ITO-804 Assignment -1

Ques 1: Write a Python program that takes a list of daily stock prices as input, and returns the best days to buy and sell stocks in order to maximize profit. The list 
contains the stock prices for each day, starting from the first day. For example, the list (100, 180, 260, 310, 40, 535, 695) represents the stock prices for 7 days, 
where the price on the first day is 100, the second day is 180, and so on. The program should find the best days to buy and sell stocks such that the profit obtained is
maximum. For instance, in the given list of stock prices, the best days to buy and sell stocks would be: Buy stock on the 1st day (price=100) Sell stock on the 4th day 
(price=310) Buy stock on the 5th day (price=40) Sell stock on the 7th day (price=695) The program should output these buy and sell days as a tuple or list of integers.
give me solution of this program.

Ques 2: You are given a list of book titles and their corresponding publication years. Your task is to find the earliest year in which a trilogy of books was published. A
trilogy is defined as a series of three books published in consecutive years. For example, consider the following list of book titles and publication years:
titles = ['The Hunger Games', 'Catching Fire', 'Mockingjay', 'The Lord of the Rings', 'The Two Towers', 'The Return of the King', 'Divergent', 'Insurgent', 'Allegiant'] 
years = [2008, 2009, 2010, 1954, 1955, 1956, 2011, 2012, 2013].
The earliest year in which a trilogy was published is 1954.

Ques 3: Write a Python program that reads in a CSV file of stock prices (e.g. ticker symbol, date, price), and then uses dictionaries and lists to calculate the highest
and lowest prices for each stock from following table: 
![image](https://user-images.githubusercontent.com/61160172/230786965-456865b1-16fb-4ee7-b02d-2bd387b74cc1.png)

Ques 4: A) Write a Python program to remove duplicates from a list of lists. Sample list: [[10, 20], [40], [30, 56, 25], [10, 20], [33], [40]] 

Ques 4: (B): Write a Python program which takes a list and returns a list with the elements "shifted left by one position" so [1, 2, 3] yields [2, 3, 1]

Ques 4 (C) : Iterate a given list and count the occurrence of each element and create a dictionary to show the count of each element. 
